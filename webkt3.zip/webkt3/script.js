class CardComponent extends HTMLElement {
    constructor() {
        super();
        this.shadow = this.attachShadow({ mode: 'open' });
    }

    // вызывается браузером в момент когда кард компонент появляется
    connectedCallback() {
        this._unpackTemplates();
        this._render();
        this._loadStyles();
        this._attachDeleteHandler();
    }

    // находит темплейт из штмл, исходник удаляет
    _unpackTemplates() {
        const templates = this.querySelectorAll('template[slot]');
        templates.forEach(tmpl => {
            const slotName = tmpl.getAttribute('slot');
            const wrapper = document.createElement('div');
            wrapper.setAttribute('slot', slotName);
            wrapper.appendChild(tmpl.content.cloneNode(true));
            this.appendChild(wrapper);
            this.removeChild(tmpl);
        });
    }


    // отрисовка
    _render() {
        const cardHTML = `
            <div class="card">
                <button class="btn-delete" title="Удалить карточку">×</button>
                <div class="card-header">
                    <slot name="header"></slot>
                </div>
                <div class="card-content">
                    <slot name="content"></slot>
                </div>
            </div>
        `;
        this.shadow.innerHTML = cardHTML;
    }

    // подключает стили

    _loadStyles() {
        const link = document.createElement('link');
        link.setAttribute('rel', 'stylesheet');
        link.setAttribute('href', 'style.css');
        this.shadow.appendChild(link);
    }

    // для удаления
    _attachDeleteHandler() {
        const deleteBtn = this.shadow.querySelector('.btn-delete');
        if (deleteBtn) {
            deleteBtn.addEventListener('click', () => {
                this.remove();
            });
        }
    }
}

customElements.define('card-component', CardComponent);

// создание карточки
document.getElementById('cardForm').addEventListener('submit', function(e) {
    e.preventDefault();

    const headerText = document.getElementById('headerInput').value.trim();
    const contentText = document.getElementById('contentInput').value.trim();
    const imageUrl = document.getElementById('imageInput').value.trim();

    const card = document.createElement('card-component');

    const headerTemplate = document.createElement('template');
    headerTemplate.setAttribute('slot', 'header');
    if (headerText) {
        const h2 = document.createElement('h2');
        h2.textContent = headerText;
        headerTemplate.content.appendChild(h2);
    }

    const contentTemplate = document.createElement('template');
    contentTemplate.setAttribute('slot', 'content');
    if (contentText) {
        const p = document.createElement('p');
        p.textContent = contentText;
        contentTemplate.content.appendChild(p);
    }
    if (imageUrl) {
        const img = document.createElement('img');
        img.src = imageUrl;
        img.alt = 'Изображение карточки';
        contentTemplate.content.appendChild(img);
    }

    card.appendChild(headerTemplate);
    card.appendChild(contentTemplate);

    document.getElementById('cardsContainer').appendChild(card);

    this.reset();
    document.getElementById('headerInput').focus();
});