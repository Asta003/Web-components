class FinancialCalculator extends HTMLElement {

    constructor() {
        super();
        console.log('Компонент создан');

        this.attachShadow({ mode: 'open' });

        this._amount = 1000000;
        this._rate = 10;
        this._term = 12;
    }

    connectedCallback() {
        console.log('Компонент добавлен в DOM');
        this._render();
        this._bindEvents();
        this._calculate();
    }

    disconnectedCallback() {
        console.log('Компонент удалён из DOM');
    }

    static get observedAttributes() {
        return ['amount', 'rate', 'term'];
    }

    attributeChangedCallback(name, oldValue, newValue) {
        if (oldValue === newValue) return;

        console.log('Данные обновлены: ' + name + ' изменено с ' + oldValue + ' на ' + newValue);

        const num = parseFloat(newValue);
        if (isNaN(num)) return;

        if (name === 'amount') this._amount = num;
        if (name === 'rate')   this._rate   = num;
        if (name === 'term')   this._term   = Math.round(num);

        if (this.shadowRoot.querySelector('#monthly')) {
            this._syncInputs();
            this._calculate();
        }
    }

    _render() {
        this.shadowRoot.innerHTML = `
            <link rel="stylesheet" href="style.css">

            <h2>Кредитный калькулятор</h2>

            <div class="form-group">
                <label for="amount">Сумма кредита (₽)</label>
                <input type="number" id="amount"
                       value="${this._amount}" min="1" step="1000">
            </div>

            <div class="form-group">
                <label for="rate">Процентная ставка (%)</label>
                <input type="number" id="rate"
                       value="${this._rate}" min="0.1" max="100" step="0.1">
            </div>

            <div class="form-group">
                <label for="term">Срок кредита (мес.)</label>
                <input type="number" id="term"
                       value="${this._term}" min="1" max="360" step="1">
            </div>

            <div class="results">
                <div class="result-item">
                    <span class="result-label">Ежемесячный платёж:</span>
                    <span class="result-value" id="monthly">—</span>
                </div>
                <div class="result-item">
                    <span class="result-label">Общая сумма выплат:</span>
                    <span class="result-value" id="total">—</span>
                </div>
                <div class="result-item">
                    <span class="result-label">Общий процент по кредиту:</span>
                    <span class="result-value" id="overpay">—</span>
                </div>
            </div>

            <div class="error" id="error"></div>
        `;
    }

    _bindEvents() {
        const fields = ['amount', 'rate', 'term'];

        fields.forEach(field => {
            const input = this.shadowRoot.getElementById(field);

            input.addEventListener('input', () => {
                const value = parseFloat(input.value);

                if (!this._validate(field, value)) return;

                this[`_${field}`] = field === 'term' ? Math.round(value) : value;
                this.setAttribute(field, this[`_${field}`]);
                this._calculate();
            });
        });
    }

    _validate(field, value) {
        const err = this.shadowRoot.getElementById('error');
        const input = this.shadowRoot.getElementById(field);

        const labels = { amount: 'Сумма', rate: 'Ставка', term: 'Срок' };

        if (isNaN(value) || value <= 0) {
            this._showError(labels[field] + ' должна быть положительным числом');
            input.classList.add('invalid');
            return false;
        }

        if (field === 'rate' && (value < 0.1 || value > 100)) {
            this._showError('Ставка должна быть от 0.1% до 100%');
            input.classList.add('invalid');
            return false;
        }

        if (field === 'term' && (value < 1 || value > 360)) {
            this._showError('Срок должен быть от 1 до 360 месяцев');
            input.classList.add('invalid');
            return false;
        }

        input.classList.remove('invalid');
        err.classList.remove('visible');
        return true;
    }

    _showError(msg) {
        const err = this.shadowRoot.getElementById('error');
        err.textContent = msg;
        err.classList.add('visible');
    }

    _calculate() {
        const P = this._amount;
        const r = this._rate / 100 / 12;
        const n = this._term;

        const monthly = r === 0
            ? P / n
            : P * (r * Math.pow(1 + r, n)) / (Math.pow(1 + r, n) - 1);

        const total   = monthly * n;
        const overpay = total - P;

        this.shadowRoot.getElementById('monthly').textContent = this._fmt(monthly);
        this.shadowRoot.getElementById('total').textContent   = this._fmt(total);
        this.shadowRoot.getElementById('overpay').textContent  = this._fmt(overpay);
    }

    _syncInputs() {
        this.shadowRoot.getElementById('amount').value = this._amount;
        this.shadowRoot.getElementById('rate').value   = this._rate;
        this.shadowRoot.getElementById('term').value   = this._term;
    }

    _fmt(value) {
        return new Intl.NumberFormat('ru-RU', {
            style: 'currency',
            currency: 'RUB',
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        }).format(value);
    }
}

customElements.define('financial-calculator', FinancialCalculator);