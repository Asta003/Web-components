class ExpenseCalculator extends HTMLElement {
    constructor() {
        super();

        this._expenses = [];

        this.expenses = new Proxy(this._expenses, {
            set: (target, property, value) => {
                target[property] = value;
                this.render();
                return true;
            },
            deleteProperty: (target, property) => {
                delete target[property];
                this.render();
                return true;
            }
        });

        this.render();
    }

    render() {
        const total = this._expenses.reduce((sum, e) => sum + Number(e.amount), 0);

        this.innerHTML = `
            <h1>Калькулятор расходов</h1>

            <form id="expense-form" autocomplete="off">
                <input class="full" type="text" id="name" placeholder="Название расхода" autocomplete="off">
                <input type="number" id="amount" placeholder="Сумма" step="0.01" autocomplete="off">
                <button class="add" type="submit">Добавить</button>
            </form>

            <div class="total">
                Общая сумма: <span>${total.toFixed(2)} ₽</span>
            </div>

            <ul id="list">
                ${this._expenses.length === 0
                    ? '<li class="empty">Список пуст</li>'
                    : this._expenses.map((e, i) => `
                        <li>
                            <div class="info">
                                <span class="name">${this.escape(e.name)}</span>
                                <span class="amount">${Number(e.amount).toFixed(2)} ₽</span>
                            </div>
                            <div class="actions">
                                <button class="icon-btn add-sub-btn" data-index="${i}" title="Добавить к расходу">+</button>
                                <button class="icon-btn delete" data-index="${i}" title="Удалить">✕</button>
                            </div>
                            <div class="add-sub" id="sub-form-${i}" style="display: none;">
                                <input type="number" placeholder="Сумма" step="0.01" autocomplete="off">
                                <button class="confirm-sub" data-index="${i}">Добавить</button>
                            </div>
                        </li>
                    `).join('')}
            </ul>
        `;

        this.attachEvents();
    }

    escape(str) {
        return String(str)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;');
    }

    attachEvents() {
        const form = this.querySelector('#expense-form');
        const list = this.querySelector('#list');

        // Добавление нового расхода
        form.addEventListener('submit', (e) => {
            e.preventDefault();
            const nameInput = this.querySelector('#name');
            const amountInput = this.querySelector('#amount');

            const name = nameInput.value.trim() || 'Без названия';
            const amount = parseFloat(amountInput.value) || 0;

            this.expenses.push({ name, amount });

            form.reset();
            this.querySelector('#name').focus();
        });

        list.addEventListener('click', (e) => {
            // Удаление
            if (e.target.classList.contains('delete')) {
                const index = Number(e.target.dataset.index);
                this.expenses.splice(index, 1);
            }

            // Показ формы
            if (e.target.classList.contains('add-sub-btn')) {
                const index = Number(e.target.dataset.index);
                const subForm = this.querySelector(`#sub-form-${index}`);
                const isVisible = subForm.style.display === 'flex';
                subForm.style.display = isVisible ? 'none' : 'flex';
                if (!isVisible) {
                    subForm.querySelector('input').focus();
                }
            }

            // Подтверждение добавления
            if (e.target.classList.contains('confirm-sub')) {
                const index = Number(e.target.dataset.index);
                const subForm = this.querySelector(`#sub-form-${index}`);
                const input = subForm.querySelector('input');
                const amount = parseFloat(input.value) || 0;

                if (amount > 0) {
                    this.expenses[index] = {
                        ...this._expenses[index],
                        amount: this._expenses[index].amount + amount
                    };
                }

                subForm.style.display = 'none';
                input.value = '';
            }
        });
    }
}
// Регистр компонента
customElements.define('expense-calculator', ExpenseCalculator);