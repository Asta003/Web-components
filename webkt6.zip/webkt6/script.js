class TaskList extends HTMLElement {
  constructor() {
    super();
    this.attachShadow({ mode: 'open' });
    this.tasks = new Map();
    this.nextId = 1;
  }

  connectedCallback() {
    if (this.shadowRoot.innerHTML) return;
    this.render();
  }

  render() {
    this.shadowRoot.innerHTML = `
      <link rel="stylesheet" href="style.css">
      <div class="card" part="card">
        <h2>Список задач</h2>
        <form part="form" novalidate>
          <input type="text" placeholder="Новая задача…" maxlength="200">
          <button type="submit" class="btn-add" disabled>Добавить</button>
        </form>
        <ul part="list"></ul>
        <p class="counter">Выполнено: 0 из 0</p>
      </div>
    `;

    const $ = (sel) => this.shadowRoot.querySelector(sel);
    this.ui = {
      form: $('form'),
      input: $('input'),
      list: $('ul'),
      empty: $('.empty'),
      counter: $('.counter'),
      btn: $('.btn-add')
    };

    this.ui.form.addEventListener('submit', (e) => {
      e.preventDefault();
      const text = this.ui.input.value.trim();
      if (!text) return;
      this.addTask(text);
      this.ui.input.value = '';
      this.ui.btn.disabled = true;
      this.ui.input.focus();
    });

    this.ui.input.addEventListener('input', () => {
      this.ui.btn.disabled = !this.ui.input.value.trim();
    });

    this.ui.list.addEventListener('click', (e) => {
      if (e.target.closest('.btn-remove')) {
        this.removeTask(e.target.closest('li').dataset.id);
      }
    });

    this.ui.list.addEventListener('change', (e) => {
      if (e.target.matches('input[type="checkbox"]')) {
        this.toggleTask(e.target.closest('li').dataset.id, e.target.checked);
      }
    });
  }

  addTask(title) {
    const id = String(this.nextId++);
    const li = document.createElement('li');
    li.dataset.id = id;
    li.innerHTML = `<input type="checkbox"> <span class="title"></span> <button type="button" class="btn-remove">✕</button>`;
    li.querySelector('.title').textContent = title; 
    this.ui.list.appendChild(li);
    this.tasks.set(id, { el: li, done: false });
    this.updateUI();
  }

  removeTask(id) {
    const task = this.tasks.get(id);
    if (!task) return;
    task.el.remove();
    this.tasks.delete(id);
    this.updateUI();
  }

  toggleTask(id, done) {
    const task = this.tasks.get(id);
    if (!task) return;
    task.done = done;
    task.el.classList.toggle('done', done);
    this.updateUI();
  }

  updateUI() {
    this.ui.empty.style.display = this.tasks.size ? 'none' : '';
    const doneCount = [...this.tasks.values()].filter(t => t.done).length;
    this.ui.counter.textContent = `Выполнено: ${doneCount} из ${this.tasks.size}`;
  }
}

customElements.define('task-list', TaskList);