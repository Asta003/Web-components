import os
import re

def test_files_exist():
    """Проверяет, что все необходимые файлы лежат в папке проекта"""
    assert os.path.exists('index.html'), "Ошибка: Нет файла index.html"
    assert os.path.exists('style.css'), "Ошибка: Нет файла style.css"
    assert os.path.exists('script.js'), "Ошибка: Нет файла script.js"

def test_html_structure():
    """Проверяет правильность подключения скриптов и стилей в HTML"""
    with open('index.html', 'r', encoding='utf-8') as f:
        html = f.read()
    
    assert '<task-list></task-list>' in html, "Ошибка: Не найден тег <task-list>"
    assert 'style.css' in html, "Ошибка: Не подключен style.css"
    assert 'script.js' in html, "Ошибка: Не подключен script.js"

def test_web_component_usage():
    """Проверяет, что в JS используется современный веб-компонент и Shadow DOM"""
    with open('script.js', 'r', encoding='utf-8') as f:
        js = f.read()
    
    assert 'class TaskList extends HTMLElement' in js, "Ошибка: Класс не наследуется от HTMLElement"
    assert 'this.attachShadow' in js, "Ошибка: Не используется Shadow DOM (изоляция стилей)"
    assert 'customElements.define' in js, "Ошибка: Компонент не зарегистрирован"

def test_optimization_techniques():
    """Проверяет, что код оптимизирован (использует Map и точечные операции)"""
    with open('script.js', 'r', encoding='utf-8') as f:
        js = f.read()
    
    assert 'new Map()' in js, "Ошибка: Не используется Map (оптимизация поиска)"
    assert 'appendChild' in js, "Ошибка: Не используется appendChild (оптимизация добавления)"
    assert '.remove()' in js, "Ошибка: Не используется .remove() (оптимизация удаления)"

def test_security_xss():
    """Проверяет, что текст вставляется безопасно (защита от XSS)"""
    with open('script.js', 'r', encoding='utf-8') as f:
        js = f.read()
    
    assert 'textContent' in js, "Ошибка: Не используется textContent (уязвимость к XSS)"

def test_css_styles():
    """Проверяет, что стили написаны и содержат ключевые классы"""
    with open('style.css', 'r', encoding='utf-8') as f:
        css = f.read()
    
    assert '.card' in css, "Ошибка: Нет стилей для .card"
    assert ':host' in css, "Ошибка: Нет стилей для :host (Shadow DOM)"
    assert 'fadeIn' in css, "Ошибка: Нет анимации появления задач"