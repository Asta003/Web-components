class WeatherWidget extends HTMLElement {
    constructor() {
        super();
        this.attachShadow({ mode: 'open' });
        this.API_KEY = 'e8ede4f02a7d8986478d00ad65880d23';
    }

    connectedCallback() {
        this.render();
        this.shadowRoot.querySelector('form').onsubmit = (e) => {
            e.preventDefault();
            const city = this.shadowRoot.querySelector('.search-input').value.trim();
            if (city) this.searchCity(city);
        };
        this.searchCity('Москва');
    }

    render() {
        this.shadowRoot.innerHTML = `
            <style>
                :host {
                    display: block;
                    font-family: 'Segoe UI', sans-serif;
                    border-radius: 36px;
                    padding: 0; /* Убрали padding, чтобы форма прилегала к краям */
                    color: #333;
                    overflow: hidden; /* Обрезает всё, что вылезает */
                    box-shadow: 0 24px 48px rgba(0,0,0,0.1);
                    transition: background 0.8s ease, color 0.8s ease;
                }

                /* Пастельные цвета карточки в зависимости от погоды */
                :host(.weather-clear) { background: linear-gradient(135deg, #fff5e1 0%, #fde2e4 100%); }
                :host(.weather-clouds) { background: linear-gradient(135deg, #f1f4f8 0%, #e2e8f0 100%); }
                :host(.weather-rain) { background: linear-gradient(135deg, #c3d9e9 0%, #e0eafc 100%); }
                :host(.weather-snow) { background: linear-gradient(135deg, #ffffff 0%, #f0f4f8 100%); }

                /* Внутренний контейнер с отступами */
                .widget-inner {
                    padding: 32px;
                }

                .search-form {
                    display: flex;
                    gap: 12px;
                    margin-bottom: 24px;
                }

                .search-input {
                    flex: 1;
                    padding: 16px 20px;
                    border: none;
                    border-radius: 20px;
                    background: rgba(255, 255, 255, 0.7);
                    color: #333;
                    font-size: 1.1em;
                    outline: none;
                    box-shadow: inset 0 2px 4px rgba(0,0,0,0.02);
                }

                .search-input::placeholder { color: #888; }

                .search-btn {
                    padding: 16px 24px;
                    border: none;
                    border-radius: 20px;
                    background: rgba(0, 0, 0, 0.06);
                    color: inherit;
                    font-weight: 700;
                    font-size: 1.1em;
                    cursor: pointer;
                    transition: background 0.3s;
                }

                .search-btn:hover { background: rgba(0, 0, 0, 0.1); }

                .widget-header {
                    display: flex;
                    justify-content: space-between;
                    align-items: flex-end;
                    margin-bottom: 24px;
                    padding-bottom: 16px;
                    border-bottom: 1px solid rgba(0, 0, 0, 0.06);
                }

                .city-name {
                    font-size: 1.8em;
                    font-weight: 700;
                    text-transform: capitalize;
                }

                .city-name::after {
                    content: '';
                    display: block;
                    width: 50px;
                    height: 5px;
                    background: currentColor;
                    margin-top: 10px;
                    border-radius: 3px;
                    opacity: 0.15;
                }

                .date {
                    font-size: 1em;
                    opacity: 0.6;
                }

                .main-info {
                    display: flex;
                    align-items: center;
                    justify-content: space-between;
                    margin: 30px 0;
                }

                .temperature {
                    font-size: 5.5em;
                    font-weight: 300;
                    line-height: 1;
                }

                .weather-icon {
                    font-size: 5em;
                    line-height: 1;
                    filter: drop-shadow(0 6px 10px rgba(0,0,0,0.08));
                }

                .description {
                    font-size: 1.3em;
                    text-transform: capitalize;
                    margin-bottom: 30px;
                    opacity: 0.8;
                }

                .description::before {
                    content: '📍 ';
                }

                .details {
                    display: flex;
                    gap: 20px;
                }

                .detail-item {
                    flex: 1;
                    background: rgba(255, 255, 255, 0.5);
                    padding: 20px;
                    border-radius: 24px;
                }

                .label {
                    font-size: 0.85em;
                    opacity: 0.6;
                    text-transform: uppercase;
                    display: block;
                    margin-bottom: 6px;
                }

                .value {
                    font-weight: 700;
                    font-size: 1.4em;
                }

                .status {
                    text-align: center;
                    padding: 50px 0;
                    font-style: italic;
                    opacity: 0.6;
                    font-size: 1.2em;
                }

                .error {
                    color: #e74c3c;
                }
            </style>

            <div class="widget-inner">
                <form class="search-form">
                    <input type="text" class="search-input" placeholder="Поиск города..." value="Москва">
                    <button type="submit" class="search-btn">Найти</button>
                </form>

                <div class="widget-content">
                    <div class="status">Загрузка...</div>
                </div>
            </div>
        `;
    }

    async searchCity(city) {
        const content = this.shadowRoot.querySelector('.widget-content');
        content.innerHTML = '<div class="status">Загрузка...</div>';
        
        try {
            const res = await fetch(`https://api.openweathermap.org/data/2.5/weather?q=${encodeURIComponent(city)}&appid=${this.API_KEY}&units=metric&lang=ru`);
            if (!res.ok) throw new Error(res.status === 404 ? 'Город не найден' : 'Ошибка сети');
            const d = await res.json();
            
            const iconCode = d.weather[0].icon;
            const iconMap = { '01': '☀️', '02': '⛅', '03': '⛅', '04': '☁️', '09': '🌧', '10': '🌧', '11': '⛈', '13': '🌨', '50': '🌫' };
            const icon = iconMap[iconCode.slice(0, 2)] || '☀️';

            this.className = ''; 
            if (iconCode.includes('01')) this.classList.add('weather-clear');
            else if (iconCode.includes('02') || iconCode.includes('03') || iconCode.includes('04')) this.classList.add('weather-clouds');
            else if (iconCode.includes('09') || iconCode.includes('10') || iconCode.includes('11')) this.classList.add('weather-rain');
            else if (iconCode.includes('13')) this.classList.add('weather-snow');
            else this.classList.add('weather-clouds');

            content.innerHTML = `
                <div class="widget-header">
                    <span class="city-name">${d.name}</span>
                    <span class="date">${new Date().toLocaleDateString('ru-RU', { day: 'numeric', month: 'long' })}</span>
                </div>
                <div class="main-info">
                    <div class="temperature">${d.main.temp > 0 ? '+' : ''}${Math.round(d.main.temp)}°</div>
                    <div class="weather-icon">${icon}</div>
                </div>
                <div class="description">${d.weather[0].description}</div>
                <div class="details">
                    <div class="detail-item"><span class="label">Влажность</span><span class="value">${d.main.humidity}%</span></div>
                    <div class="detail-item"><span class="label">Ветер</span><span class="value">${d.wind.speed} м/с</span></div>
                </div>
            `;
        } catch (e) {
            content.innerHTML = `<div class="status error">⚠️ ${e.message}</div>`;
        }
    }
}
customElements.define('weather-widget', WeatherWidget);