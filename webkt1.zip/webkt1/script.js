// Данные контактов
const contacts = [
  {
    image: './photo/image.png',
    name: 'Левина Анастасия',
    email: 'levlev@mail.ru',
    phone: '+7 (914) 696-67-69'
  },
  {
    image: './photo/image copy 4.png',
    name: 'Потапова Виктория',
    email: 'mnogonozhka@gmail.com',
    phone: '+7 (924) 796-76-66'
  },
  {
    image: './photo/image copy 3.png',
    name: 'Ившина Анастасия',
    email: 'ivikivi@mail.ru',
    phone: '+7 (914) 969-76-96'
  }
];

const template = document.getElementById('contact-card');
const container = document.getElementById('contactsContainer');

function createContactCard(contact) {
  const clone = template.content.cloneNode(true);

  clone.querySelector('.contact-img').src = contact.image;
  clone.querySelector('.contact-img').alt = `Фото ${contact.name}`;
  clone.querySelector('.contact-name').textContent = contact.name;
  clone.querySelector('.contact-email').textContent = contact.email;
  clone.querySelector('.contact-phone').textContent = contact.phone;

  return clone;
}

contacts.forEach(contact => {
  container.appendChild(createContactCard(contact));
});